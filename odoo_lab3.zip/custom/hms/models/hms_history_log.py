from odoo import models, fields, api


class LogHistory(models.Model):
    _name = 'hms.log.history'
    description = fields.Text()
    patient = fields.Many2one('hms.patient')
    doctor = fields.Many2one('hms.doctors')

