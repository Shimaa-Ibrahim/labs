from odoo import models, fields, api


class Doctor(models.Model):
    _name = 'hms.doctors'
    _rec_name = 'name'
    first_name = fields.Char()
    last_name = fields.Char()
    image = fields.Binary()
    patients = fields.Many2many('hms.patient')

    name = fields.Char(string='Doctors names', compute='_compute_fields_combination')

    @api.depends('first_name', 'last_name')
    def _compute_fields_combination(self):
        for test in self:
            test.name = test.first_name + ' ' + test.last_name
