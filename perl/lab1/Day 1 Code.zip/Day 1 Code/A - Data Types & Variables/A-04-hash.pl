#!/usr/bin/perl 

# Defining Hash variable using '%' 
%data = ('XYZ', 55, 'LGH', 80, 'KMR', 44); 
%data2 = ('x' => 3, 'y' => 5, 'z' => 10);

# Printing values of Hash variables 
print "\$data{'XYZ'} = $data{'XYZ'}\n"; 
print "\$data{'LGH'} = $data{'LGH'}\n"; 
print "\$data{'KMR'} = $data{'KMR'}\n"; 


# Printing values of Hash variables 
print "\$data{'x'} = $data2{'x'}\n"; 
print "\$data{'y'} = $data2{'y'}\n"; 
print "\$data{'z'} = $data2{'z'}\n"; 

