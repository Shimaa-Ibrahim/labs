#!/usr/bin/perl 

# Assiging values to Array variables 
@ages = (55, 80, 44); # @ is used to declare 
						# array variables	 
@names = ("XYZ", "LGH", "KMR"); 

# Printing values of Arrays 
print "\$ages[0] = $ages[0]\n"; 
print "\$ages[1] = $ages[1]\n"; 
print "\$ages[2] = $ages[2]\n"; 
print "\$names[0] = $names[0]\n"; 
print "\$names[1] = $names[1]\n"; 
print "\$names[2] = $names[2]\n"; 



print "last element = $ages[-1]\n"; 
