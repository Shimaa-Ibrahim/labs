#!/usr/bin/perl 
use strict;           #Pragma
use warnings;    #Pragma
print "Hello World !\n"; 