# Initializing Hash with Key-Value pairs 
%stud = ('Comp' => 45, 'Inft' => 42, 'Extc' => 35); 

# Extracting values from hash 
@value_array = values %stud; 

# Printing the extracted values 
print "Values are :\n"; 
print "$value_array[0]\n"; 
print "$value_array[1]\n"; 
print "$value_array[2]\n"; 

