# Initializing Hash with Key-Value pairs 
%stud = ('Comp' => 45, 'Inft' => 42, 'Extc' => 35); 

# Extracting keys from hash 
@Key_array = keys %stud; 

# Printing the extracted keys 
print "Keys are :\n"; 
print "$Key_array[0]\n"; 
print "$Key_array[1]\n"; 
print "$Key_array[2]\n"; 

