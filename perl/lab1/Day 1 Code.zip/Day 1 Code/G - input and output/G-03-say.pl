#!/usr/bin/perl -w 
use 5.010; 

# Defining a string 
$string1 = "ITI"; 
$string2 = "Open Source"; 

# say() function to print 
say("$string1"); 
say("$string2"); 

