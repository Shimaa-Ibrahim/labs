#!/usr/bin/perl -w 
	
# Defining a string 
$string1 = "ITI"; 
$string2 = "Open Source"; 

print "$string1"; 
print "$string2"; 

