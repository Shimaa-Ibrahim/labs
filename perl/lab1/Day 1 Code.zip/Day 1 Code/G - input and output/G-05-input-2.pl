#!/usr/bin/perl -w 
use strict; 
use warnings; 

print"Enter some text:"; 
my $string = <STDIN>; 
chomp $string; 

print "You entered $string as a String"; 




