# Perl program to demonstrate the working  
# of Ternary Operator 
  
$x = 5; 
$y = 10; 
  
# To find which value is greater 
# Using Ternary Operator 
$result = $x > $y ? $x : $y; 
  
# displaying the output 
print "The Larger Number is: $result"  
