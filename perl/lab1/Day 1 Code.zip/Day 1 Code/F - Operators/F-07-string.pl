# Perl program to demonstrate the 
# string operators 

#!/usr/bin/perl 

# Input first string 
$first_string = "Open"; 

# Input second string 
$second_string = "Source"; 

# Implement Concatination operator(.) 
$concat_string = $first_string.$second_string; 

# displaying concatination string result 
print "Result of Concatenation Operator = $concat_string\n"; 

# Input a string 
$string = "ITI "; 

# Using Repetation operator(x) 
$str_result = $string x 4; 

# Display output 
# print string 4 times 
print "Result of Repetation Operator = $str_result"; 

