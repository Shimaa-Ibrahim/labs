# Perl program to demonstrate the Auto 
# Increment and Decrement Operator 

#!/usr/local/bin/perl 

# taking a variable 
$g = 10; 

# using pre Increment 
$res = ++$g; 

print "Value of res is = $res\n"; 
print "Value of g is = $g\n"; 

# taking a variable 
$g1 = 15; 

# using post Increment 
$res1 = $g1++; 

print "Value of res1 is = $res1\n"; 
print "Value of g1 is = $g1\n"; 

# taking a variable 
$g2 = 20; 

# using pre Decrement 
$res2 = --$g2; 

print "Value of res2 is = $res2\n"; 
print "Value of g2 is = $g2\n"; 

# taking a variable 
$g3 = 25; 

# using post Decrement 
$res3 = $g3--; 

print "Value of res3 is = $res3\n"; 
print "Value of g3 is = $g3\n"; 

