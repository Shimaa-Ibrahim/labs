# Perl Program to illustrate the Airthmetic Operators 
  
# Operands 
$a = 10; 
$b = 4; 
  
# using airthmetic operators  
print "Addition is: ", $a + $b, "\n"; 
print "Subtraction is: ", $a - $b, "\n" ; 
print "Multiplication is: ", $a * $b, "\n"; 
print "Division is: ", $a / $b, "\n"; 
print "Modulus is: ", $a % $b, "\n"; 
print "Exponent is: ", $a ** $b, "\n"; 
