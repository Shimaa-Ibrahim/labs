# Perl program to demonstrate the 
# Range operators 
  
#!/usr/bin/perl 
  
# using range operator   
@res = (1..4); 
  
# Display output 
print "Result of Range Operator = @res"; 
