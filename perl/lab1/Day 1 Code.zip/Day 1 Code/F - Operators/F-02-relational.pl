# Perl Program to illustrate the Relational Operators 

# Operands 
$a = 10; 
$b = 60; 

# using Relational Operators 
if ($a == $b) 
{ 
print "Equal To Operator is True\n"; 
} 
else
{ 
print "Equal To Operator is False\n"; 
} 

if ($a != $b) 
{ 
print "Not Equal To Operator is True\n"; 
} 
else
{ 
print "Not Equal To Operator is False\n"; 
} 

if ($a > $b) 
{ 
print "Greater Than Operator is True\n"; 
} 
else
{ 
print "Greater Than Operator is False\n"; 
} 

if ($a < $b) 
{ 
print "Less Than Operator is True\n"; 
} 
else
{ 
print "Less Than Operator is False\n"; 
} 

if ($a >= $b) 
{ 
print "Greater Than Equal To Operator is True\n"; 
} 
else
{ 
print "Greater Than Equal To Operator is False\n"; 
} 

if ($a <= $b) 
{ 
print "Less Than Equal To Operator is True\n"; 
} 
else
{ 
print "Less Than Equal To Operator is False\n"; 
} 
if ($a <=> $b) 
{ 
print "Comparison of Operator is True\n"; 
} 
else
{ 
print "Comparison of Operator is False\n"; 
} 

