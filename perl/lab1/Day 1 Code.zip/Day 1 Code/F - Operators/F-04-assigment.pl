# Perl program to demonstrate the working 
# of Assignment Operators 
#!/usr/local/bin/perl 

# taking two variables & using 
# simple assignments operation 
$a = 8; 
$b = 5; 

# using Assignment Operators 
print "Addition Assignment Operator: ", $a += $b, "\n"; 

$a = 8; 
$b = 4; 
print "Subtractation Assignment Operator: ", $a -= $b, "\n" ; 

$a = 8; 
$b = 4; 
print "Multiplication Assignment Operator: ", $a*=$b, "\n"; 

$a = 8; 
$b = 4; 
print "Division Assignment Operator: ",$a/=$b, "\n"; 

$a = 8; 
$b = 5; 
print "Modulo Assignment Operator: ", $a%=$b,"\n"; 

$a = 8; 
$b = 4; 
print "Exponent Assignment Operator: ", $a**=$b, "\n"; 
		

