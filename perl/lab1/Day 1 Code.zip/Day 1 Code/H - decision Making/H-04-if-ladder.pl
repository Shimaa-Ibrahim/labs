# Perl program to illustrate 
# if - elseif ladder statement 

$i = 20; 

if($i == 10) 
{ 
	printf "i is 10\n"; 
} 

elsif($i == 15) 
{ 
	printf "i is 15\n"; 
} 

elsif($i == 20) 
{ 
	printf "i is 20\n"; 
} 

else
{ 
	printf "i is not present\n"; 
} 

