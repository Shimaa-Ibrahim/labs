# Perl program to illustrate 
# if - else statement 

$a = 21; 

# if condition to check 
# for even number 
if($a % 2 == 0 ) 
{ 
	printf "Even Number"; 
} 
else
{ 
	printf "Odd Number\n"; 
} 

