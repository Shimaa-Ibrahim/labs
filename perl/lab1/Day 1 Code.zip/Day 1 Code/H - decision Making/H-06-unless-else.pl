# Perl program to illustrate 
# unless - else statement 

$a = 10; 

unless($a == 10) 
{ 

	# if condition is false then 
	# print the following 
	printf "a is not equal to 10\n"; 
} 

else
{ 

	# if condition is true then 
	# print the following 
	printf "a is equal to 10\n"; 
} 

