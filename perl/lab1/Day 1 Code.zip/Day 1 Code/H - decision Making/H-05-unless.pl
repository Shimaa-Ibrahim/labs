# Perl program to illustrate 
# unless statement 

$a = 10; 

unless($a != 10) 
{ 

	# if condition is false then 
	# print the following 
	printf "a is not equal to 10\n"; 
} 

