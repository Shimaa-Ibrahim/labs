# Perl program to illustrate if statement 

$a = 10; 

# if condition to check 
# for even number 
if($a % 2 == 0 ) 
{ 
	printf "Even Number"; 
} 

