# Perl program to demonstrate 
# string uc function 

# string 
my $s = "iti"; 

# using uc function & 
# displaying result 
print("To Upper Case: "); 
print(uc($s),"\n"); 

