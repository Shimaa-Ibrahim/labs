# Perl program to demonstrate 
# string length function 

# string 
my $s = "ITI"; 

# using length function & 
# displaying length 
print(length($s),"\n"); 

