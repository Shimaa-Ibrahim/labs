#!/usr/bin/perl 

# Assining a variable with an price 
# using double-quotes 
$price = "$9.95";

# Printing the interpolated string 
print($price); 

print("\n");

# using single-quote 
$price = '$9.95';

# Printing the interpolated string 
print($price); 

