#!/usr/bin/perl 

# Assining a variable with an email address 
# using double-quotes 
$email = "ziyad.a.elgendy@gmail.com"; 

# Printing the interpolated string 
print($email); 

print("\n");

# using single-quote 
$email = 'ziyad.a.elgendy@gmail.com'; 

# Printing the interpolated string 
print($email); 

