# Perl program to demonstrate 
# string lc function 

# string 
my $s = "ITI\n"; 

# using lc function & 
# displaying result 
print("To lower case: "); 
print(lc($s),"\n"); 

