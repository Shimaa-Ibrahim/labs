#!/usr/bin/perl 

# Initalizing the array 
@x = ('Java', 'C', 'C++'); 

# Print the Inital array 
print "Original array: @x \n"; 

# Prints the value returned by pop 
print "Value returned by pop: ", pop(@x); 

# Prints the array after pop operation 
print "\nUpdated array: @x"; 

