#!/usr/bin/perl 

# Initalizing the array 
@x = ('Java', 'C', 'C++'); 

# Print the Inital array 
print "Original array: @x \n"; 

# Pushing multiple values in the array 
print "Number of elements: ", push(@x, 'Python', 'Perl'); 

# Printing the array 
print "\n Updated array: @x"; 

