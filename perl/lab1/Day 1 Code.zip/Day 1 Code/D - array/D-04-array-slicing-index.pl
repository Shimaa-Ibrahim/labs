#!/usr/bin/perl 

# Perl program to implement the use of Array Slice 
@array = ('ITI', 'Open', 'Source'); 

# Using slicing method 
@extracted_elements = @array[1, 2]; 

# Printing the extracted elements 
print"Extracted elements: ". 
	"@extracted_elements"; 

