# Perl Code to demonstrate the True values 
  
# variable assigned value 5 
$a = 5; 
  
# checking whether a is true or false 
if ($a) 
{ 
    print "a is True\n"; 
} 
else
{ 
    print "a is False\n"; 
}  
  
# string variable assigned white  
# space character 
$b = ' '; 
  
# checking whether b is true or false 
if ($b) 
{ 
    print "b is True\n"; 
} 
else
{ 
    print "b is False\n"; 
}  
  
# string variable assigned 'false' 
# value to it 
$c = 'false'; 
  
# checking whether c is true or false 
if ($c) 
{ 
    print "c is True\n"; 
} 
else
{ 
    print "c is False\n"; 
}  
  
# string variable assigned "0\n" 
# value to it 
$d = "0\n"; 
  
# checking whether d is true or false 
if ($d) 
{ 
    print "d is True\n"; 
} 
else
{ 
    print "d is False\n"; 
}  

