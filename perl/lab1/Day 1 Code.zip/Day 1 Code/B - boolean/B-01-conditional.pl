# Perl Program demonstrate the conditional check 
  
# variable initialized with string 
$x = "ITI"; 
  
# using if statement 
if ($x eq "ITI") 
{ 
    print "Return True\n"; 
} 
else
{ 
    print "Return False\n"; 
} 
