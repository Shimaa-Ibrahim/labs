# Perl Code to demonstrate the False values 
  
# variable assigned value 0 
$a = 0; 
  
# checking whether a is true or false 
if ($a) 
{ 
    print "a is True\n"; 
} 
else
{ 
    print "a is False\n"; 
}  
  
# string variable assigned empty string 
$b = '0'; 
  
# checking whether b is true or false 
if ($b) 
{ 
    print "b is True\n"; 
} 
else
{ 
    print "b is False\n"; 
}  
  
# string variable assigned undef 
$c = undef; 
  
# checking whether c is true or false 
if ($c) 
{ 
    print "c is True\n"; 
} 
else
{ 
    print "c is False\n"; 
}  
  
# string variable assigned "" 
# value to it 
@p = (); 
  
# checking whether d is true or false 
if ($p) 
{ 
    print "d is True\n"; 
} 
else
{ 
    print "d is False\n"; 
}  
