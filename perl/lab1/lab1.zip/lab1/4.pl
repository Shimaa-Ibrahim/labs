#!/usr/bin/perl 
use 5.010;
use Math::Trig;
say('insert redius:');
chomp ($r = <>);    
say(2*$r*pi()); 