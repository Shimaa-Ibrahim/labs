#!/usr/bin/perl 
use 5.010;
use Math::Trig;    
say(2*12.2*pi()); 