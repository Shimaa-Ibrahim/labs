#!/usr/bin/perl





rename("/home/ziyad/test/old.txt", "/home/ziyad/test/new.txt") 
|| die "Cannot rename file.txt: $!";