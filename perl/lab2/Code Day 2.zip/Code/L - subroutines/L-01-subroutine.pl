# Perl Program to demonstrate the 
# subroutine declaration and calling 

#!/usr/bin/perl 

# defining subroutine 
sub greet_user { 
print "Hello ITIans!\n"; 
} 

# calling subroutine 
# you can also use 
# &greet_user(); 
greet_user(); 

