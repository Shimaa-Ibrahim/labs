# Perl program to illustrate until Loop 

$a = 10; 

# until loop 
until ($a < 1) 
{ 
	print "$a "; 
	$a = $a - 1; 
} 

