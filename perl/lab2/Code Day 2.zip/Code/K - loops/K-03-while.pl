# Perl program to illustrate 
# the while loop 

# while loop 
$count = 3; 
while ($count >= 0) 
{ 
	$count = $count - 1; 
	print "ITI\n"; 
} 

