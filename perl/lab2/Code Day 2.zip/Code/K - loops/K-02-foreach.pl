# Perl program to illustrate 
# the foreach loop 

# Array 
@data = ('ITI', 'Open Source', 'Nasr City'); 

# foreach loop 
foreach  (@data) 
{ 
	print $_;
} 

