# Perl program to illustrate 
# the for loop 

# for loop 
for ($count = 1 ; $count <= 3 ; $count++) 
{ 
	print "Open Source\n"
} 

