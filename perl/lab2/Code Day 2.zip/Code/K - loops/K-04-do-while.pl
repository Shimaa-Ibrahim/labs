# Perl program to illustrate 
# do..while Loop 

$a = 10; 

# do..While loop 
do { 

	print "$a "; 
	$a = $a - 1; 
} while ($a > 0); 

