from odoo import models, fields, api, exceptions
from datetime import datetime
import re


class Patient(models.Model):
    _name = 'hms.patient'
    first_name = fields.Char()
    last_name = fields.Char()
    birth_date = fields.Date()
    history = fields.Html()
    CR_ratio = fields.Float()
    blood_type = fields.Selection([
        ('O', 'O'),
        ('A', 'A'),
        ('B', 'B'),
        ('AB', 'AB')
    ])
    PCR = fields.Boolean()
    image = fields.Binary()
    address = fields.Text()
    age = fields.Integer(compute='_calc_age', store="True")
    state = fields.Selection([
        ('Undetermined', 'Undetermined'),
        ('Good', 'Good'),
        ('Fair', 'Fair'),
        ('Serious', 'Serious')
    ])
    department = fields.Many2one('hms.department')
    doctors = fields.Many2many('hms.doctors')
    department_capacity = fields.Integer(related='department.capacity')
    name = fields.Char(string='Patients names', compute='_compute_fields_combination')
    email = fields.Char()
    logs = fields.One2many('hms.log.history','patient')

    @api.constrains('email')
    def _valid_email(self):
        for record in self:
            match = re.search('^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$', record.email)
            if match is None:
                raise exceptions.UserError("invalid email!")

    _sql_constraints = [
        ('Duplicate Email', 'UNIQUE(email)', 'this email already exists')
    ]

    @api.depends('first_name', 'last_name')
    def _compute_fields_combination(self):
        for test in self:
            test.name = test.first_name + ' ' + test.last_name

    @api.onchange("age")
    def onchange_age(self):
        warning = {}
        if 0 < self.age and self.age< 30:
            self.PCR = True
            warning = {
                "title": "Age Warning",
                "message": "PCR should be true if age < 30"
            }
            return {
                'warning': warning

            }

    @api.onchange("state")
    def onchange_state(self):
        if len(self.ids) != 0:
            logs = self.env['hms.log.history'].create({
                'patient': self.ids[0],
                'description': f"state changed to {self.state}"
            })

    @api.depends("birth_date")
    def _calc_age(self):
        for patient in self:
            if patient.birth_date:
                db = datetime.strptime(str(patient.birth_date), "%Y-%m-%d")
                age_calc = (datetime.today() - db).days / 365
                age = str(age_calc)
                patient.age = int(age.split('.')[0])
