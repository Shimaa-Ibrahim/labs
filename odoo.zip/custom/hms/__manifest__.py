{
    "name": "ITI odoo Hospital",
    "author": "iti odoo course",
    "depends": [],
    "data": [
        "views/hms_patient_views.xml",
        "views/hms_department_views.xml",
        "views/hms_doctors_views.xml",
        "views/hms_logs_views.xml"
    ]

}
