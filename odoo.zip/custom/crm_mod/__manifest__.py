{
    "name": "ITI CRM",
    "author": "ITI odoo course",
    "depends": ['crm'],
    "data": ['views/res_partner_views.xml']
}