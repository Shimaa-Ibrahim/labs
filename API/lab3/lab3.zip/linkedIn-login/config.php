<?php
define('CLIENT_ID','77olmh39tt8byp');
define('CLIENT_SECRET','66B6UGMatPX9dj6B');
define('REDIRECT_URL','http://localhost:8000/redirect.php');
?>