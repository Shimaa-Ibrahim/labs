from odoo import models, fields, api, exceptions


class CmrCustomerInherit(models.Model):
    _inherit = 'res.partner'
    related_patient_id = fields.Many2one('hms.patient')
    vat = fields.Char(required="True")

    def unlink(self):
        for record in self:
            if record.related_patient_id:
                raise exceptions.UserError('cannot delete this customer, have related patient!')
            return super().unlink()

    @api.constrains('email')
    def _check_mail(self):
        for record in self:
            result = self.env['hms.patient'].search([('email', '=', record.email)])
            if len(result) == 1:
                raise exceptions.UserError('this email already exists')
